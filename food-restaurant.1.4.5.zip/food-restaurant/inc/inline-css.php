<?php
	
	$food_restaurant_custom_css = '';
	
	/*-------------- Footer Text -------------------*/
	$food_restaurant_copyright_text_position = get_theme_mod('food_restaurant_copyright_text_position','center');
	if($food_restaurant_copyright_text_position != false){
		$food_restaurant_custom_css .='.copyright{';
			$food_restaurant_custom_css .='text-align: '.esc_attr($food_restaurant_copyright_text_position).';';
		$food_restaurant_custom_css .='}';
	}

	/*----------------Width Layout -------------------*/
    $food_restaurant_theme_lay = get_theme_mod( 'food_restaurant_width_options','Full Width');
    if($food_restaurant_theme_lay == 'Full Width'){
		$food_restaurant_custom_css .='body{';
			$food_restaurant_custom_css .='max-width: 100%;';
		$food_restaurant_custom_css .='}';
	}else if($food_restaurant_theme_lay == 'Contained Width'){
		$food_restaurant_custom_css .='body{';
			$food_restaurant_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$food_restaurant_custom_css .='}';
	}else if($food_restaurant_theme_lay == 'Boxed Width'){
		$food_restaurant_custom_css .='body{';
			$food_restaurant_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$food_restaurant_custom_css .='}';
	}

	//Submenu Dropdown Effect
	$food_restaurant_dropdown_anim = get_theme_mod('food_restaurant_dropdown_anim');
	$food_restaurant_custom_css .='.primary-navigation ul ul{';
		$food_restaurant_custom_css .='animation: '.esc_attr($food_restaurant_dropdown_anim).' 1s ease;';
	$food_restaurant_custom_css .='}';

	/*-------- footer background css -------*/
	$food_restaurant_footer_background_color = get_theme_mod('food_restaurant_footer_background_color');
	$food_restaurant_custom_css .='.footersec{';
		$food_restaurant_custom_css .='background-color: '.esc_attr($food_restaurant_footer_background_color).';';
	$food_restaurant_custom_css .='}';

    /*-------- Copyright background css -------*/
	$food_restaurant_copyright_background_color = get_theme_mod('food_restaurant_copyright_background_color');
	$food_restaurant_custom_css .='.copyright-wrapper{';
		$food_restaurant_custom_css .='background-color: '.esc_attr($food_restaurant_copyright_background_color).';';
	$food_restaurant_custom_css .='}';

	// site title and tagline font size option
	$food_restaurant_site_title_font_size = get_theme_mod('food_restaurant_site_title_font_size', 33);{
	$food_restaurant_custom_css .='.header .logo a{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_site_title_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_site_tagline_font_size = get_theme_mod('food_restaurant_site_tagline_font_size', 14);{
	$food_restaurant_custom_css .='.header .logo p{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_site_tagline_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	// logo size option
	$food_restaurant_logo_size = get_theme_mod('food_restaurant_logo_size');{
	$food_restaurant_custom_css .='.header .logo img{';
	$food_restaurant_custom_css .='width: '.esc_attr($food_restaurant_logo_size).'px !important;';
		$food_restaurant_custom_css .='}';
	}

	//slider color
	$food_restaurant_slider_title_font_size = get_theme_mod('food_restaurant_slider_title_font_size');{
	$food_restaurant_custom_css .='#slider .inner_carousel h1{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_slider_title_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_slider_text_font_size = get_theme_mod('food_restaurant_slider_text_font_size');{
	$food_restaurant_custom_css .='#slider .inner_carousel p{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_slider_text_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_slider_title_color = get_theme_mod('food_restaurant_slider_title_color');
	$food_restaurant_custom_css .='#slider .inner_carousel h1{';
		$food_restaurant_custom_css .='color: '.esc_attr($food_restaurant_slider_title_color).';';
	$food_restaurant_custom_css .='}';

	$food_restaurant_slider_text_color = get_theme_mod('food_restaurant_slider_text_color');
	$food_restaurant_custom_css .='#slider .inner_carousel p{';
		$food_restaurant_custom_css .='color: '.esc_attr($food_restaurant_slider_text_color).';';
	$food_restaurant_custom_css .='}';

	//food product css
	$food_restaurant_product_img_height = get_theme_mod('food_restaurant_product_img_height');{
	$food_restaurant_custom_css .='.service-box-img img{';
	$food_restaurant_custom_css .='height: '.esc_attr($food_restaurant_product_img_height).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_product_sec_title_font_size = get_theme_mod('food_restaurant_product_sec_title_font_size');{
	$food_restaurant_custom_css .='.blog-head strong{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_product_sec_title_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_product_sec_subtitle_font_size = get_theme_mod('food_restaurant_product_sec_subtitle_font_size');{
	$food_restaurant_custom_css .='.blog-head p.sub-heading{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_product_sec_subtitle_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_product_sec_short_line_font_size = get_theme_mod('food_restaurant_product_sec_short_line_font_size');{
	$food_restaurant_custom_css .='.blog-head p{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_product_sec_short_line_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}

	$food_restaurant_product_font_size = get_theme_mod('food_restaurant_product_font_size');{
	$food_restaurant_custom_css .='section#products .wc-block-components-product-title a{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_product_font_size).'px !important;';
		$food_restaurant_custom_css .='}';
	}
     
	//food product css
	$food_restaurant__product_title_color = get_theme_mod('food_restaurant__product_title_color');
	$food_restaurant_custom_css .='.blog-head strong{';
		$food_restaurant_custom_css .='color: '.esc_attr($food_restaurant__product_title_color).';';
	$food_restaurant_custom_css .='}';

	$food_restaurant__product_subtitle_color = get_theme_mod('food_restaurant__product_subtitle_color');
	$food_restaurant_custom_css .='.blog-head p.sub-heading{';
		$food_restaurant_custom_css .='color: '.esc_attr($food_restaurant__product_subtitle_color).';';
	$food_restaurant_custom_css .='}';

	$food_restaurant__product_bdr_color = get_theme_mod('food_restaurant__product_bdr_color');
	$food_restaurant_custom_css .='.blog-head p.sub-heading::before {';
		$food_restaurant_custom_css .='background-color: '.esc_attr($food_restaurant__product_bdr_color).';';
	$food_restaurant_custom_css .='}';

	$food_restaurant__product_sline_color = get_theme_mod('food_restaurant__product_sline_color');
	$food_restaurant_custom_css .='.blog-head p{';
		$food_restaurant_custom_css .='color: '.esc_attr($food_restaurant__product_sline_color).';';
	$food_restaurant_custom_css .='}';

	$food_restaurant__product_text_color = get_theme_mod('food_restaurant__product_text_color');
	$food_restaurant_custom_css .='.box-image p{';
		$food_restaurant_custom_css .='color: '.esc_attr($food_restaurant__product_text_color).';';
	$food_restaurant_custom_css .='}';

	//Footer css
	$food_restaurant_footer_copy_font_size = get_theme_mod('food_restaurant_footer_copy_font_size');{
	$food_restaurant_custom_css .='.copyright a{';
	$food_restaurant_custom_css .='font-size: '.esc_attr($food_restaurant_footer_copy_font_size).'px;';
		$food_restaurant_custom_css .='}';
	}