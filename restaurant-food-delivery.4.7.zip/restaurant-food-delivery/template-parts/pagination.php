<?php
	the_posts_pagination( array(
		'prev_text' => esc_html__( 'Previous page', 'restaurant-food-delivery' ),
		'next_text' => esc_html__( 'Next page', 'restaurant-food-delivery' ),
	) );